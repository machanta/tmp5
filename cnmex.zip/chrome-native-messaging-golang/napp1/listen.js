
var nativePort = null;
var messageArrived,msg = null;
chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
      blacklistedWebsite = 'http : / / yourdomain . com /';
      if (sender.url == blacklistedWebsite)
        return;  // don't allow this web page access
      if (request.message === 'connect') {
        connectNative();
        alert('backend received - ' + request.message);
        if (nativePort)
          sendResponse({"success": true, "message": "connected to backend"}); // sending back the acknowlege to the webpage
      } else {

          messageArrived,msg = new Promise(resolve => messageArrived = resolve);
          awaitResp(sendResponse);
          alert('backend received - ' + JSON.stringify(request));
          sendNativeMessage(request);
         //sendResponse({"success": true, "message": "From Backend - " + request.message});
      }
  });

  async function awaitResp(sendResponse) {
      const message = await msg;
      sendResponse(message);
  }
  function connectNative() {
    var hostName = "com.sample.native_msg_golang";
    nativePort = chrome.runtime.connectNative(hostName);
    nativePort.onMessage.addListener(onNativeMessage);
    nativePort.onDisconnect.addListener(onDisconnected);
  }



function sendNativeMessage(message) {

    nativePort.postMessage(message);

  }

  function onNativeMessage(message) {
      messageArrived(message);
  }

  function onDisconnected() {
   console.log("Failed to connect: " + chrome.runtime.lastError.message);
    nativePort = null;

  }