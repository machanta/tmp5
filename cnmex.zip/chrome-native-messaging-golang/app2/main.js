// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

var port = null;
var connected = false;

var getKeys = function(obj){
   var keys = [];
   for(var key in obj){
      keys.push(key);
   }
   return keys;
}

function appendMessage(text) {
  document.getElementById('response').innerHTML += "<p>" + text + "</p>";
}

function updateUiState() {
  if (connected) {
    document.getElementById('connect-button').style.display = 'none';
    document.getElementById('input-text').style.display = 'inline-block';
    document.getElementById('send-message-button').style.display = 'inline-block';
  } else {
    document.getElementById('connect-button').style.display = 'block';
    document.getElementById('input-text').style.display = 'none';
    document.getElementById('send-message-button').style.display = 'none';
  }
}

function sendMessage() {
  message = {"message": document.getElementById('input-text').value.trim()};
  port.postMessage(message);
  appendMessage("Sent message: <b>" + JSON.stringify(message) + "</b>");
}

function onNativeMessage(message) {
  appendMessage("Received message: <b>" + JSON.stringify(message) + "</b>");
}

function onDisconnected() {
  appendMessage("Failed to connect: " + chrome.runtime.lastError.message);
  connected = false;
  port = null;
  updateUiState();
}

function connect() {



 /* var port = chrome.runtime.connect("ghbmnnjooekpmoecnnnilnnbdlolhkhi", {name: "wf-wmit-ms"});
  port.sendMessage({message: "connect"});
  port.onMessage.addListener(function(msg) {
    if (msg.message === "connected") {
        connected = true;
        appendMessage("Connected to native messaging host ");
        updateUiState();
    }
     // port.postMessage({answer: "Madame"});
    else if (msg.message === "Madame who?"){

    }

  });


  port.onDisconnect.addListener(onDisconnected);
*/

  window.postMessage({type:"FWP", name: "wf-wmit-ms", message: "connect"},"*");
  window.addEventListener("message", (event) => {
    // We only accept messages from ourselves
  //  if (event.source != window) {
 //     return;
  //  }
    appendMessage("Meesage received: " +JSON.stringify(event));
    updateUiState();
});

}

document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('connect-button').addEventListener('click', connect);
  document.getElementById('send-message-button').addEventListener('click', sendMessage);
  updateUiState();
});
